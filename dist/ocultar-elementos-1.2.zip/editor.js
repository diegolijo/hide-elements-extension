(function () {
  const dn = globalThis.__dn;
  let editorRoot = null;

  const TABS = ['Clases', 'Caja', 'Posición', 'Margen', 'Relleno', 'Display', 'Color'];
  const POSITIONS = ['static', 'relative', 'absolute', 'fixed', 'sticky'];
  const OFFSETS = [
    ['Superior', 'top'],
    ['Derecha', 'right'],
    ['Inferior', 'bottom'],
    ['Izquierda', 'left']
  ];
  const SIDES = [
    ['Superior', 'top'],
    ['Derecha', 'right'],
    ['Inferior', 'bottom'],
    ['Izquierda', 'left']
  ];
  const DISPLAYS = ['block', 'inline', 'inline-block', 'flex', 'grid', 'none'];
  const COLORS = [
    ['Texto', 'color'],
    ['Fondo', 'background-color'],
    ['Borde', 'border-color']
  ];

  function h(tag, attrs, children) {
    const node = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([key, value]) => {
      if (value == null || value === false) {
        return;
      }
      if (key === 'class') {
        node.className = value;
      } else if (key === 'text') {
        node.textContent = value;
      } else {
        node.setAttribute(key, value);
      }
    });
    (children || []).forEach((child) => {
      if (child) {
        node.append(child);
      }
    });
    return node;
  }

  function current(element, prop) {
    const inline = element.style.getPropertyValue(prop);
    if (inline.trim()) {
      return inline.trim();
    }
    let value = getComputedStyle(element).getPropertyValue(prop).trim();
    if (prop === 'align-items' && value === 'normal') value = 'stretch';
    if (prop === 'justify-content' && value === 'normal') value = 'flex-start';
    if (prop === 'flex-direction' && value === 'normal') value = 'row';
    return value;
  }

  function formatPx(element, prop) {
    const inline = element.style.getPropertyValue(prop).trim();
    if (inline) {
      return inline;
    }
    const computed = getComputedStyle(element).getPropertyValue(prop).trim();
    if (!computed || computed === 'auto' || computed === 'normal') {
      return computed || 'auto';
    }
    const value = parseFloat(computed);
    if (Number.isNaN(value)) {
      return computed;
    }
    return Math.round(value) + 'px';
  }

  function readBase(element, prop) {
    const inline = element.style.getPropertyValue(prop).trim();
    if (inline && inline !== 'auto') {
      const inlineValue = parseFloat(inline);
      if (!Number.isNaN(inlineValue)) {
        return inlineValue;
      }
    }
    const computed = parseFloat(getComputedStyle(element).getPropertyValue(prop));
    if (!Number.isNaN(computed)) {
      return computed;
    }
    return 0;
  }

  function stepProp(element, prop, delta) {
    const next = Math.round(readBase(element, prop) + delta);
    element.style.setProperty(prop, next + 'px');
  }

  function stepper(element, label, prop, withAuto) {
    const children = [
      h('span', { class: 'name', text: label }),
      h('button', { type: 'button', 'data-step': prop, 'data-d': '-10', text: '-10' }),
      h('button', { type: 'button', 'data-step': prop, 'data-d': '-1', text: '-1' }),
      h('span', { class: 'val', text: formatPx(element, prop) }),
      h('button', { type: 'button', 'data-step': prop, 'data-d': '1', text: '+1' }),
      h('button', { type: 'button', 'data-step': prop, 'data-d': '10', text: '+10' })
    ];
    if (withAuto) {
      children.push(h('button', { type: 'button', 'data-auto': prop, text: 'auto' }));
    }
    return h('div', { class: 'row' }, children);
  }

  function keywords(element, prop, values) {
    const valueNow = current(element, prop);
    return h('div', { class: 'group' }, values.map((value) => {
      return h('button', {
        type: 'button',
        class: value === valueNow ? 'is-on' : '',
        'data-set': prop,
        'data-value': value,
        text: value
      });
    }));
  }

  function sideSteppers(element, prefix, withAuto) {
    return h('div', { class: 'stack' }, SIDES.map(([label, side]) => {
      return stepper(element, label, prefix + side, withAuto);
    }));
  }

  function toggleClass(element, name) {
    let removed = dn.removedClasses.get(element);
    if (!removed) {
      removed = new Set();
      dn.removedClasses.set(element, removed);
    }
    if (element.classList.contains(name)) {
      element.classList.remove(name);
      removed.add(name);
      return;
    }
    element.classList.add(name);
    removed.delete(name);
  }

  function classesTab(element) {
    const removed = dn.removedClasses.get(element) || new Set();
    const names = [...element.classList, ...removed].filter((name) => name && name !== 'hide-cursor');
    if (!names.length) {
      return h('p', { class: 'empty', text: 'Sin clases' });
    }
    return h('div', { class: 'chips' }, names.map((name) => {
      const on = element.classList.contains(name);
      return h('button', {
        type: 'button',
        class: on ? 'chip' : 'chip is-off',
        'data-class-name': name,
        text: name
      });
    }));
  }

  function positionTab(element) {
    const position = current(element, 'position');
    const blocks = [keywords(element, 'position', POSITIONS)];
    if (position === 'absolute' || position === 'fixed' || position === 'sticky') {
      blocks.push(h('div', { class: 'stack' }, OFFSETS.map(([label, prop]) => {
        return stepper(element, label, prop, true);
      })));
    }
    return h('div', { class: 'stack' }, blocks);
  }

  function flexTab(element) {
    if (current(element, 'display') !== 'flex') {
      return null;
    }
    return h('div', { class: 'stack' }, [
      h('span', { class: 'cap', text: 'Dirección' }),
      keywords(element, 'flex-direction', ['row', 'column', 'row-reverse', 'column-reverse']),
      h('span', { class: 'cap', text: 'Ajuste' }),
      keywords(element, 'flex-wrap', ['nowrap', 'wrap']),
      h('span', { class: 'cap', text: 'justify-content' }),
      keywords(element, 'justify-content', ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly']),
      h('span', { class: 'cap', text: 'align-items' }),
      keywords(element, 'align-items', ['flex-start', 'center', 'flex-end', 'stretch']),
      stepper(element, 'Gap', 'gap', false)
    ]);
  }

  function toHex(value) {
    if (!value) {
      return '#000000';
    }
    const hex = String(value).trim();
    if (/^#[0-9a-fA-F]{6}$/.test(hex)) {
      return hex.toLowerCase();
    }
    if (/^#[0-9a-fA-F]{3}$/.test(hex)) {
      return '#' + hex.slice(1).split('').map((char) => char + char).join('').toLowerCase();
    }
    if (/^#[0-9a-fA-F]{8}$/.test(hex)) {
      return hex.slice(0, 7).toLowerCase();
    }
    const match = hex.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/i);
    if (!match) {
      return '#000000';
    }
    const channel = (part) => Math.max(0, Math.min(255, Math.round(Number(part)))).toString(16).padStart(2, '0');
    return '#' + channel(match[1]) + channel(match[2]) + channel(match[3]);
  }

  function readColor(element, prop) {
    if (prop === 'background-color') {
      if (element.dataset.dnUserBg === '1' && element.dataset.dnUserBgValue) {
        return toHex(element.dataset.dnUserBgValue);
      }
      if (element.dataset.dnComputedBg) {
        return toHex(element.dataset.dnComputedBg);
      }
    }
    if (prop === 'border-color') {
      return toHex(getComputedStyle(element).borderTopColor);
    }
    return toHex(getComputedStyle(element).getPropertyValue(prop));
  }

  function applyColor(element, prop, value) {
    if (!element) {
      return;
    }
    if (prop === 'background-color') {
      element.dataset.dnUserBg = '1';
      element.dataset.dnUserBgValue = value;
      if (element === dn.state.selected || element === dn.state.hovered) {
        const color = element === dn.state.selected ? dn.ORANGE : dn.RED;
        dn.paint(element, color);
      } else {
        element.style.removeProperty('background-color');
        element.style.setProperty('background-color', value);
      }
      return;
    }
    if (prop === 'border-color' && getComputedStyle(element).borderTopWidth === '0px') {
      element.style.borderStyle = 'solid';
      element.style.borderWidth = '1px';
    }
    element.style.setProperty(prop, value);
  }

  function colorTab(element) {
    const canDrop = typeof EyeDropper === 'function';
    return h('div', { class: 'stack' }, COLORS.map(([label, prop]) => {
      const input = h('input', { type: 'color', 'data-color': prop, value: readColor(element, prop), title: label });
      const drop = h('button', {
        type: 'button',
        class: 'icon',
        'data-drop': prop,
        title: canDrop ? 'Cuentagotas' : 'El cuentagotas no está disponible'
      });
      drop.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M19.3 4.7a3 3 0 0 0-4.2 0l-1.1 1.1-1.4-1.4-1.4 1.4 1.4 1.4L4 15.8V20h4.2l8.6-8.6 1.4 1.4 1.4-1.4-1.4-1.4 1.1-1.1a3 3 0 0 0 0-4.2z"></path></svg>';
      drop.disabled = !canDrop;
      return h('div', { class: 'row' }, [
        h('span', { class: 'name', text: label }),
        input,
        drop
      ]);
    }));
  }

  function tabBody(element) {
    const tab = dn.state.editorTab;
    if (tab === 'Clases') {
      return classesTab(element);
    }
    if (tab === 'Caja') {
      return h('div', { class: 'stack' }, [
        stepper(element, 'Ancho', 'width', false),
        stepper(element, 'Alto', 'height', false)
      ]);
    }
    if (tab === 'Posición') {
      return positionTab(element);
    }
    if (tab === 'Margen') {
      return sideSteppers(element, 'margin-', false);
    }
    if (tab === 'Relleno') {
      return sideSteppers(element, 'padding-', false);
    }
    if (tab === 'Display') {
      return h('div', { class: 'stack' }, [
        keywords(element, 'display', DISPLAYS),
        flexTab(element)
      ]);
    }
    return colorTab(element);
  }

  function build(element) {
    const tabs = h('div', { class: 'tabs' }, TABS.map((name) => {
      return h('button', {
        type: 'button',
        class: name === dn.state.editorTab ? 'is-on' : '',
        'data-tab': name,
        text: name
      });
    }));
    return h('div', {}, [tabs, h('div', { class: 'tab-body' }, [tabBody(element)])]);
  }

  async function pickColor(element, prop) {
    if (typeof EyeDropper !== 'function' || !element) {
      return;
    }
    try {
      const result = await new EyeDropper().open();
      applyColor(element, prop, result.sRGBHex);
      if (editorRoot && dn.state.selected) {
        dn.renderEditor(editorRoot, dn.state.selected);
      }
    } catch (error) {
      void error;
    }
  }

  function onEditorClick(event) {
    const element = dn.state.selected;
    if (!element || !element.isConnected) {
      return;
    }
    const stepBtn = event.target.closest('[data-step]');
    if (stepBtn) {
      const prop = stepBtn.getAttribute('data-step');
      stepProp(element, prop, Number(stepBtn.getAttribute('data-d')));
      const val = stepBtn.parentElement.querySelector('.val');
      if (val) {
        val.textContent = formatPx(element, prop);
      }
      return;
    }
    const setBtn = event.target.closest('[data-set]');
    if (setBtn) {
      element.style.setProperty(setBtn.getAttribute('data-set'), setBtn.getAttribute('data-value'));
      dn.renderEditor(editorRoot, element);
      return;
    }
    const autoBtn = event.target.closest('[data-auto]');
    if (autoBtn) {
      element.style.setProperty(autoBtn.getAttribute('data-auto'), 'auto');
      dn.renderEditor(editorRoot, element);
      return;
    }
    const classBtn = event.target.closest('[data-class-name]');
    if (classBtn) {
      toggleClass(element, classBtn.getAttribute('data-class-name'));
      dn.ui.refresh();
      return;
    }
    const tabBtn = event.target.closest('[data-tab]');
    if (tabBtn) {
      dn.state.editorTab = tabBtn.getAttribute('data-tab');
      dn.renderEditor(editorRoot, element);
      return;
    }
    const dropBtn = event.target.closest('[data-drop]');
    if (dropBtn) {
      pickColor(element, dropBtn.getAttribute('data-drop'));
    }
  }

  function onEditorInput(event) {
    const input = event.target.closest('[data-color]');
    const element = dn.state.selected;
    if (!input || !element) {
      return;
    }
    applyColor(element, input.getAttribute('data-color'), input.value);
  }

  dn.renderEditor = function (container, element) {
    editorRoot = container;
    if (container.dataset.bound !== '1') {
      container.dataset.bound = '1';
      container.addEventListener('click', onEditorClick);
      container.addEventListener('input', onEditorInput);
    }
    container.replaceChildren(build(element));
  };
})();
